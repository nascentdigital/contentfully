# Contentfully

A simple but performant REST client for Contentful.