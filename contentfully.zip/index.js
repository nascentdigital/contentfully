// exports
exports.ContentfulClient = require("./lib/ContentfulClient");